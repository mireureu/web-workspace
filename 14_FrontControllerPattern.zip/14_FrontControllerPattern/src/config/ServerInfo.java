package config;

public interface ServerInfo {
	String DRIVER_NAME = "oracle.jdbc.driver.OracleDriver";
	String URL = "jdbc:oracle:thin:@localhost:1521:xe";
	String USER = "sample";
	String PASSWORD = "SAMPLE";
}