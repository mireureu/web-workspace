package pattern.action;

/*
 * Framework 기술
 * Struts1 --> Struts2 --> Spring Framework  
 * */

public interface Action {
	void execute(); // public abstract 
	

}
